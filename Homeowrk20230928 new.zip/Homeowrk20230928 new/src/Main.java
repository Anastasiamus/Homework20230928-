public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        char myChar= 'G';
        System.out.println(myChar);
        int myInt= 89;
        System.out.println(myInt);
        byte myByte= 4;
        System.out.println(myByte);
        short myShort= 56;
        System.out.println(myShort);
        float myFloat= 4.7333436F;
        System.out.println(myFloat);
        double myDouble= 4.355453532;
        System.out.println(myDouble);
        long myLong= 12121;
        System.out.println(myLong);



    }
}
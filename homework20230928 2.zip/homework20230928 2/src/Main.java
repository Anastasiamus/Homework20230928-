public class Main {
    public static void main(String[] args) {
        int numberMain = 681;
        int number1 = numberMain/100;
        int number2 = numberMain % 100 / 10;
        int number3 = numberMain % 10;
        System.out.println("Число" + numberMain + "->" + number1 +", " + number2 + ", " + number3 );

    }
    }
